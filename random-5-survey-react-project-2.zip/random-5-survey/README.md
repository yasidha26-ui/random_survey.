# Random 5 Survey

A responsive online survey application built with React and Vite.

## Features
- Randomly displays 5 unique questions from a question bank of 10.
- Radio-button answers for each question.
- Progress bar and required-answer validation.
- Submission summary and option to take another random survey.
- Responsive layout for mobile and desktop.

## Run locally
```bash
npm install
npm run dev
```
Open the local URL shown in the terminal, usually http://localhost:5173.

## Build check
```bash
npm run build
```

Note: This classroom demo keeps answers in the browser session only. It does not save responses to a database or collect answers from multiple users.
