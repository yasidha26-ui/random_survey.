import { useState } from "react";

const questionBank = [
  {
    id: 1,
    question: "How satisfied are you with your learning experience?",
    options: ["Very satisfied", "Satisfied", "Neutral", "Not satisfied"],
  },
  {
    id: 2,
    question: "Which way do you prefer to learn a new topic?",
    options: ["Videos", "Reading notes", "Practical activities", "Group discussion"],
  },
  {
    id: 3,
    question: "How often do you use online learning resources?",
    options: ["Every day", "A few times a week", "Sometimes", "Never"],
  },
  {
    id: 4,
    question: "How easy is it to use this survey application?",
    options: ["Very easy", "Easy", "Okay", "Difficult"],
  },
  {
    id: 5,
    question: "Would you recommend online surveys to your classmates?",
    options: ["Definitely", "Probably", "Not sure", "No"],
  },
  {
    id: 6,
    question: "Which device do you usually use for learning?",
    options: ["Laptop", "Mobile phone", "Tablet", "Desktop computer"],
  },
  {
    id: 7,
    question: "How much time do you spend learning online each day?",
    options: ["Less than 1 hour", "1–2 hours", "3–4 hours", "More than 4 hours"],
  },
  {
    id: 8,
    question: "What helps you understand a difficult topic best?",
    options: ["Examples", "Diagrams", "Practice questions", "Teacher explanation"],
  },
  {
    id: 9,
    question: "How confident are you about your technical skills?",
    options: ["Very confident", "Confident", "Somewhat confident", "Not confident yet"],
  },
  {
    id: 10,
    question: "Would you like to take more short surveys like this?",
    options: ["Yes", "Maybe", "Not sure", "No"],
  },
];

function getRandomFive() {
  // Shuffle a copy of the question bank, then take five unique questions.
  return [...questionBank].sort(() => Math.random() - 0.5).slice(0, 5);
}

export default function App() {
  const [questions, setQuestions] = useState(getRandomFive);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const answeredCount = Object.keys(answers).length;

  function chooseAnswer(questionId, answer) {
    setAnswers((previous) => ({ ...previous, [questionId]: answer }));
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (answeredCount !== 5) return;
    setSubmitted(true);
  }

  function startNewSurvey() {
    setQuestions(getRandomFive());
    setAnswers({});
    setSubmitted(false);
  }

  return (
    <main className="page-shell">
      <header className="topbar">
        <div className="brand-mark" aria-hidden="true">S</div>
        <div>
          <p className="eyebrow">QUICK • SIMPLE • YOUR VOICE</p>
          <h1>Random 5 Survey</h1>
        </div>
      </header>

      {!submitted ? (
        <section className="survey-card">
          <div className="intro">
            <span className="pill">ONLINE SURVEY</span>
            <h2>Your opinion matters.</h2>
            <p>Answer these five randomly selected questions. It only takes a minute.</p>
          </div>

          <div className="progress-row">
            <span>Progress</span>
            <strong>{answeredCount} of 5 answered</strong>
          </div>
          <div className="progress-track" aria-label={`${answeredCount * 20}% completed`}>
            <div className="progress-fill" style={{ width: `${answeredCount * 20}%` }} />
          </div>

          <form onSubmit={handleSubmit}>
            {questions.map((item, index) => (
              <fieldset className="question-block" key={item.id}>
                <legend>
                  <span className="question-number">{String(index + 1).padStart(2, "0")}</span>
                  {item.question}
                </legend>
                <div className="options-grid">
                  {item.options.map((option) => (
                    <label
                      className={`option ${answers[item.id] === option ? "selected" : ""}`}
                      key={option}
                    >
                      <input
                        type="radio"
                        name={`question-${item.id}`}
                        value={option}
                        checked={answers[item.id] === option}
                        onChange={() => chooseAnswer(item.id, option)}
                      />
                      <span className="custom-radio" />
                      <span>{option}</span>
                    </label>
                  ))}
                </div>
              </fieldset>
            ))}

            {answeredCount < 5 && (
              <p className="hint">Please answer all five questions to submit your survey.</p>
            )}
            <button className="primary-button" type="submit" disabled={answeredCount !== 5}>
              Submit survey <span aria-hidden="true">→</span>
            </button>
          </form>
          <p className="privacy-note">Your answers are used only to show this demo result.</p>
        </section>
      ) : (
        <section className="survey-card result-card" aria-live="polite">
          <div className="success-icon">✓</div>
          <span className="pill">SURVEY COMPLETED</span>
          <h2>Thank you for sharing!</h2>
          <p className="result-description">Your five answers have been recorded for this session.</p>
          <div className="answer-summary">
            {questions.map((item, index) => (
              <div className="summary-item" key={item.id}>
                <span className="summary-number">{index + 1}</span>
                <div>
                  <strong>{item.question}</strong>
                  <p>{answers[item.id]}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="primary-button" onClick={startNewSurvey}>
            Take another random survey <span aria-hidden="true">↻</span>
          </button>
        </section>
      )}

      <footer>Made with React <span>•</span> Randomly selected from a question bank</footer>
    </main>
  );
}